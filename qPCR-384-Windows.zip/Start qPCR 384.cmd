@echo off
setlocal DisableDelayedExpansion
set "QPCR_WORKBENCH_PAGE=%~dp0qPCR-384.html"
if not exist "%QPCR_WORKBENCH_PAGE%" (
    echo Extract the whole qPCR 384 ZIP before starting.
    pause
    exit /b 1
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -Command ^
    "$page = $env:QPCR_WORKBENCH_PAGE; $url = [Uri]::new($page).AbsoluteUri; " ^
    "$roots = ${env:ProgramFiles(x86)}, $env:ProgramFiles, $env:LOCALAPPDATA; " ^
    "$edge = $roots | Where-Object { $_ } | ForEach-Object { Join-Path $_ 'Microsoft\Edge\Application\msedge.exe' } | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1; " ^
    "if ($edge) { try { Start-Process -FilePath $edge -ArgumentList ('--app=' + $url) -ErrorAction Stop; exit 0 } catch {} }; " ^
    "try { Start-Process -FilePath $page -ErrorAction Stop; exit 0 } catch { exit 1 }"
if errorlevel 1 (
    echo Open qPCR-384.html in Microsoft Edge or Google Chrome.
    pause
    exit /b 1
)
